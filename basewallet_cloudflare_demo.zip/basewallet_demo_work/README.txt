BASE WALLET — CLOUDFLARE SIMULATION DEMO

SAFETY
- This is a UI demo only. All balances and withdrawals are simulated; no real funds move.
- Do not use real customer details, real bank information, real passwords, or real crypto addresses.
- The demo admin credentials are visible in the client-side code and are NOT secure. Do not use this for a real financial service.
- This migration stores demo records in Cloudflare D1.

WHAT IS INCLUDED
- Existing responsive interface, demo registration/login, admin tools, simulated credits/withdrawal requests, and support chat where the original frontend supports them.
- Cloudflare Pages Function at functions/api/[[path]].js replacing the Netlify function.
- D1 schema in schema.sql.
- Visible DEMO / SIMULATION ONLY warning on every page.

DEPLOYMENT OVERVIEW (free-tier eligible; provider limits and terms can change)
1. Unzip this project on a computer or upload the files to a private GitHub repository.
2. In Cloudflare Dashboard, open Workers & Pages and create a D1 database named base-wallet-demo-db.
3. Open the D1 database Console and run the contents of schema.sql.
4. Copy the D1 database ID. Edit wrangler.toml and replace REPLACE_WITH_YOUR_D1_DATABASE_ID.
5. Create a Cloudflare Pages project connected to the GitHub repository. Use the repository root as the project root and no build command; the output directory is ".".
6. Ensure the D1 binding is named DB and points to base-wallet-demo-db. If Cloudflare does not automatically pick up wrangler.toml, add it in Pages > Settings > Functions > D1 database bindings.
7. Deploy via Git integration (not dashboard drag-and-drop) because Pages Functions need to be compiled.
8. Test /api/health. Expected response: {"ok":true,"service":"basewallet-api"}.
9. Create test accounts only and verify persistence, admin demo controls, and support chat.

IMPORTANT NOTES
- Cloudflare Pages Functions require a build/deployment workflow that supports Functions; dashboard drag-and-drop does not compile the functions/ folder.
- No existing Netlify data is migrated automatically. This project starts with a fresh D1 database.
- This is not production-ready authentication or a real wallet. Do not collect money or promise withdrawals.
