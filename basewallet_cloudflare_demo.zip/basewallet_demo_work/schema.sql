-- Cloudflare D1 storage for the clearly labelled Base Wallet demo.
CREATE TABLE IF NOT EXISTS kv_store (
  key TEXT PRIMARY KEY NOT NULL,
  value TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_kv_store_key ON kv_store(key);
