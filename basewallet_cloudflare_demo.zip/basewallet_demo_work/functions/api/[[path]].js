import crypto from 'node:crypto';

const ADMIN_EMAIL = process.env.ADMIN_EMAIL || 'Priscillalillian303@gmail.com';
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'onekids123@@';

const response = (status, body) => new Response(JSON.stringify(body), {
  status,
  headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' }
});
const norm = s => String(s ?? '').trim().toLowerCase();
const hash = (password, salt) => crypto.pbkdf2Sync(String(password), salt, 120000, 32, 'sha256').toString('hex');
const keyUser = email => `user:${norm(email)}`;
const keyChat = email => `chat:${norm(email)}`;
const keyFunds = email => `funds:${norm(email)}`;
const keyTx = email => `tx:${norm(email)}`;
async function getJSON(env, key, fallback = null) {
  const row = await env.DB.prepare('SELECT value FROM kv_store WHERE key = ?').bind(key).first();
  if (!row) return fallback;
  try { return JSON.parse(row.value); } catch { return fallback; }
}
async function putJSON(env, key, value) {
  await env.DB.prepare('INSERT INTO kv_store (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value')
    .bind(key, JSON.stringify(value)).run();
}
async function listKeys(env, prefix) {
  const rows = await env.DB.prepare('SELECT key FROM kv_store WHERE key LIKE ? ORDER BY key').bind(prefix + '%').all();
  return (rows.results || []).map(row => ({ key: row.key }));
}
function isAdmin(req) {
  return norm(req.headers.get('x-admin-email')) === norm(ADMIN_EMAIL) && req.headers.get('x-admin-password') === ADMIN_PASSWORD;
}

export async function onRequest({ request: req, env }) {
  if (req.method === 'OPTIONS') return new Response(null, { status: 204 });
  const url = new URL(req.url);
  const parts = url.pathname.split('/').filter(Boolean);
  const action = parts.at(-1) || '';
  try {
    if (action === 'health' && req.method === 'GET') return response(200, { ok: true, service: 'basewallet-api' });

    if (action === 'register' && req.method === 'POST') {
      const b = await req.json();
      const email = norm(b.email);
      if (!email || !b.password || !b.username) return response(400, { error: 'Missing required fields' });
      const key = keyUser(email);
      if (await getJSON(env, key)) return response(409, { error: 'An account with this email already exists.' });
      const salt = crypto.randomBytes(16).toString('hex');
      const user = { email, username: String(b.username).trim(), first: String(b.first || ''), last: String(b.last || ''), phone: String(b.phone || ''), country: String(b.country || ''), level: 1, balance: 0, passwordHash: hash(b.password, salt), salt, createdAt: new Date().toISOString() };
      await putJSON(env, key, user);
      await putJSON(env, keyChat(email), []);
      await putJSON(env, keyFunds(email), {});
      await putJSON(env, keyTx(email), []);
      return response(201, { ok: true, user: { email, username: user.username, first: user.first, last: user.last, country: user.country, phone: user.phone, level: 1, balance: 0, funds: {}, transactions: [] } });
    }

    if (action === 'reset-password' && req.method === 'POST') {
      const b = await req.json();
      const email = norm(b.email);
      const phone = String(b.phone || '').replace(/\D/g, '');
      const newPassword = String(b.newPassword || '');
      if (!email || !phone || !newPassword) return response(400, { error: 'Email, phone number and new password are required.' });
      if (newPassword.length < 6) return response(400, { error: 'New password must be at least 6 characters.' });
      const key = keyUser(email);
      const user = await getJSON(env, key);
      const storedPhone = String(user?.phone || '').replace(/\D/g, '');
      if (!user) return response(404, { error: 'Account not found.' });
      if (!storedPhone || storedPhone !== phone) return response(400, { error: 'The email address and phone number do not match an account.' });
      const salt = crypto.randomBytes(16).toString('hex');
      user.passwordHash = hash(newPassword, salt);
      user.salt = salt;
      await putJSON(env, key, user);
      return response(200, { ok: true, message: 'Password changed successfully.' });
    }

    if (action === 'login' && req.method === 'POST') {
      const b = await req.json();
      const email = norm(b.email);
      const user = await getJSON(env, keyUser(email));
      if (!user || hash(b.password, user.salt) !== user.passwordHash) return response(401, { error: 'Invalid email or password.' });
      return response(200, { ok: true, user: { email, username: user.username, first: user.first, last: user.last, country: user.country, phone: user.phone, level: user.level || 1, balance: user.balance || 0, funds: await getJSON(env, keyFunds(email), {}), transactions: await getJSON(env, keyTx(email), []), levelUpdatedAt: user.levelUpdatedAt || null } });
    }

    if (action === 'chat' && req.method === 'GET') {
      const email = norm(url.searchParams.get('email'));
      if (!email) return response(400, { error: 'Missing email' });
      return response(200, { messages: await getJSON(env, keyChat(email), []) });
    }

    if (action === 'chat' && req.method === 'POST') {
      const b = await req.json();
      const email = norm(b.email);
      if (!email || !b.kind) return response(400, { error: 'Missing chat data' });
      const messages = await getJSON(env, keyChat(email), []);
      const id = String(b.id || crypto.randomUUID());
      if (!messages.some(m => m && m.id === id)) {
        messages.push({ id, kind: b.kind, text: String(b.text || ''), image: b.image || '', name: b.name || '', time: b.time || new Date().toISOString(), autoWelcome: !!b.autoWelcome });
        await putJSON(env, keyChat(email), messages);
      }
      return response(200, { ok: true, message: messages.at(-1) });
    }

    if (action === 'wallet-settings' && req.method === 'GET') {
      const settings = await getJSON(env, 'settings:wallet', { withdrawalsEnabled: true });
      return response(200, { withdrawalsEnabled: settings.withdrawalsEnabled !== false });
    }

    if (action === 'bank-details' && req.method === 'GET') {
      const details = await getJSON(env, 'settings:bank-details', { bankName: 'Demo Bank', accountName: 'Demo Account', accountNumber: '0000000000', branchCode: '000000', referenceNumber: 'DEMO-000000' });
      return response(200, { details });
    }

    if (action === 'admin-bank-details' && req.method === 'POST') {
      if (!isAdmin(req)) return response(403, { error: 'Admin required' });
      const b = await req.json();
      const details = {
        bankName: String(b.bankName || '').trim(),
        accountName: String(b.accountName || '').trim(),
        accountNumber: String(b.accountNumber || '').trim(),
        branchCode: String(b.branchCode || '').trim(),
        referenceNumber: String(b.referenceNumber || '').trim()
      };
      if (!details.bankName || !details.accountName || !details.accountNumber) {
        return response(400, { error: 'Bank name, account name and account number are required.' });
      }
      await putJSON(env, 'settings:bank-details', details);
      return response(200, { ok: true, details });
    }

    if (action === 'account' && req.method === 'GET') {
      const email = norm(url.searchParams.get('email'));
      if (!email) return response(400, { error: 'Missing email' });
      const user = await getJSON(env, keyUser(email));
      if (!user) return response(404, { error: 'Account not found.' });
      return response(200, { user: { email, username: user.username, first: user.first, last: user.last, country: user.country, level: user.level || 1, levelUpdatedAt: user.levelUpdatedAt || null }, funds: await getJSON(env, keyFunds(email), {}), transactions: await getJSON(env, keyTx(email), []) });
    }

    if (action === 'admin-users' && req.method === 'GET') {
      if (!isAdmin(req)) return response(403, { error: 'Admin required' });
      const listed = await listKeys(env, 'user:');
      const users = [];
      for (const item of listed.blobs || []) {
        const user = await getJSON(env, item.key);
        if (!user) continue;
        users.push({ email: norm(user.email), username: user.username || '', first: user.first || '', last: user.last || '', country: user.country || '', level: user.level || 1, createdAt: user.createdAt || null, funds: await getJSON(env, keyFunds(user.email), {}) });
      }
      users.sort((a,b) => String(b.createdAt || '').localeCompare(String(a.createdAt || '')));
      return response(200, { users });
    }

    if (action === 'admin-fund' && req.method === 'POST') {
      if (!isAdmin(req)) return response(403, { error: 'Admin required' });
      const b = await req.json();
      const identifier = String(b.user || '').trim();
      const asset = String(b.asset || 'USD').toUpperCase();
      const amount = Number(b.amount);
      if (!identifier || !Number.isFinite(amount) || amount <= 0) return response(400, { error: 'Enter a user and a valid positive amount.' });
      if (!['USD','USDT','BTC','ETH','BNB','SOL'].includes(asset)) return response(400, { error: 'Unsupported demo asset.' });
      let email = norm(identifier);
      let user = await getJSON(env, keyUser(email));
      if (!user && !identifier.includes('@')) {
        const listed = await listKeys(env, 'user:');
        for (const item of listed.blobs || []) {
          const candidate = await getJSON(env, item.key);
          if (candidate && norm(candidate.username) === norm(identifier)) { email = norm(candidate.email); user = candidate; break; }
        }
      }
      if (!user) return response(404, { error: 'Registered user not found. Use the exact email or username of an account created on this shared site.' });
      const funds = await getJSON(env, keyFunds(email), {});
      funds[asset] = (Number(funds[asset]) || 0) + amount;
      await putJSON(env, keyFunds(email), funds);
      return response(200, { ok: true, email, username: user.username, funds });
    }

    if (action === 'withdrawal' && req.method === 'POST') {
      const b = await req.json();
      const email = norm(b.email);
      const amount = Number(b.amount);
      if (!email || !Number.isFinite(amount) || amount <= 0) return response(400, { error: 'Enter a valid withdrawal amount.' });
      const user = await getJSON(env, keyUser(email));
      if (!user) return response(404, { error: 'Account not found.' });
      const settings = await getJSON(env, 'settings:wallet', { withdrawalsEnabled: true });
      if (!settings.withdrawalsEnabled) return response(403, { error: 'Withdrawal suspended — this demo account has been temporarily restricted by the administrator.' });
      if (Number(user.level || 1) < 2) return response(403, { error: 'Your withdrawals are currently restricted. Please contact support to resolve this.' });
      const funds = await getJSON(env, keyFunds(email), {});
      const available = (Number(funds.USD) || 0) + (Number(funds.USDT) || 0);
      if (amount > available) return response(400, { error: 'Insufficient demo balance.' });
      let remaining = amount;
      const usd = Math.min(Number(funds.USD) || 0, remaining); funds.USD = (Number(funds.USD) || 0) - usd; remaining -= usd;
      if (remaining > 0) funds.USDT = Math.max(0, (Number(funds.USDT) || 0) - remaining);
      await putJSON(env, keyFunds(email), funds);
      const transactions = await getJSON(env, keyTx(email), []);
      const tx = { id: crypto.randomUUID(), user: email, amount, method: String(b.method || 'bank'), status: 'Pending', processingMessage: 'Demo request recorded — no funds transferred', time: new Date().toISOString() };
      transactions.push(tx); await putJSON(env, keyTx(email), transactions);
      return response(200, { ok: true, funds, transaction: tx, transactions });
    }

    if (action === 'admin-withdrawals' && req.method === 'POST') {
      if (!isAdmin(req)) return response(403, { error: 'Admin required' });
      const b = await req.json();
      const enabled = !!b.enabled;
      await putJSON(env, 'settings:wallet', { withdrawalsEnabled: enabled, updatedAt: new Date().toISOString() });
      return response(200, { ok: true, withdrawalsEnabled: enabled });
    }

    if (action === 'admin-user-level' && req.method === 'POST') {
      if (!isAdmin(req)) return response(403, { error: 'Admin required' });
      const b = await req.json();
      const identifier = String(b.user || '').trim();
      const level = Number(b.level);
      const status = String(b.status || 'upgraded');
      if (!identifier) return response(400, { error: 'Missing user email or username' });
      if (!Number.isInteger(level) || level < 1 || level > 3) return response(400, { error: 'Level must be 1, 2, or 3' });
      let email = norm(identifier);
      let user = await getJSON(env, keyUser(email));
      if (!user && !identifier.includes('@')) {
        const listed = await listKeys(env, 'user:');
        for (const item of listed.blobs || []) {
          const candidate = await getJSON(env, item.key);
          if (candidate && norm(candidate.username) === norm(identifier)) { email = norm(candidate.email); user = candidate; break; }
        }
      }
      if (!user) return response(404, { error: 'User account not found.' });
      user.level = status === 'upgraded' ? level : Math.max(1, level - 1);
      if (status === 'upgraded') user.levelUpdatedAt = new Date().toISOString();
      await putJSON(env, keyUser(email), user);
      return response(200, { ok: true, email, username: user.username, level: user.level, levelUpdatedAt: user.levelUpdatedAt || null });
    }

    if (action === 'admin-chat' && req.method === 'GET') {
      if (!isAdmin(req)) return response(403, { error: 'Admin required' });
      const users = await listKeys(env, 'chat:');
      const conversations = [];
      for (const item of users.blobs || []) {
        const email = item.key.slice(5);
        const messages = await getJSON(env, item.key, []);
        if (messages.length) conversations.push({ email, messages });
      }
      return response(200, { conversations });
    }

    if (action === 'admin-reply' && req.method === 'POST') {
      if (!isAdmin(req)) return response(403, { error: 'Admin required' });
      const b = await req.json();
      const email = norm(b.email);
      if (!email) return response(400, { error: 'Missing user email' });
      const messages = await getJSON(env, keyChat(email), []);
      const id = String(b.id || crypto.randomUUID());
      if (!messages.some(m => m && m.id === id)) {
        messages.push({ id, kind: 'team', text: String(b.text || ''), image: b.image || '', time: b.time || new Date().toISOString(), autoWelcome: false });
        await putJSON(env, keyChat(email), messages);
      }
      return response(200, { ok: true });
    }

    return response(404, { error: 'Unknown endpoint' });
  } catch (error) {
    console.error(error);
    return response(500, { error: error?.message || 'Server error' });
  }
}


